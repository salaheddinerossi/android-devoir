package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.Article;

import java.util.List;

public class ArticleAdapter extends RecyclerView.Adapter<ArticleAdapter.ViewHolder> {

    private List<Article> mArticles;

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textViewId, textViewLibelle, textViewPU;

        public ViewHolder(View v) {
            super(v);
            textViewId = v.findViewById(R.id.textViewId);
            textViewLibelle = v.findViewById(R.id.textViewLibelle);
            textViewPU = v.findViewById(R.id.textViewPU);
        }
    }
    public void updateArticles(List<Article> newArticles) {
        mArticles.clear();
        mArticles.addAll(newArticles);
        notifyDataSetChanged();
    }

    // Provide a suitable constructor (depends on the kind of dataset)
    public ArticleAdapter(List<Article> articles) {
        mArticles = articles;
    }

    // Create new views (invoked by the layout manager)
    @Override
    public ArticleAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // Inflate the custom layout
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_article, parent, false);

        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Article article = mArticles.get(position);
        holder.textViewLibelle.setText(article.getLibelle()); // Assuming Article has a getLibelle method
        holder.textViewPU.setText(String.valueOf(article.getPu())); // Assuming Article has a getPU method
    }


    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return mArticles.size();
    }
}
